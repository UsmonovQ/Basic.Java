public class seller {

    public static void main(String[] args) {
        //2 Пользователь-продавец вводит суммарную стоимость покупок и сумму денег, которую дал покупатель.
        // Выведите сумму сдачи в виде “X рублей и Y копеек”.
        double[] price = {10.5, 20.0, 15.75, 8.99};
        double totalCost = calculateTotalCost(price);
        int moneyAmount = 85;
       double change =  calculateChange(totalCost, moneyAmount);
        System.out.println("Total purchase cost: " + totalCost);
        System.out.println("Available amount of money: " + moneyAmount);
        System.out.println("Change amount:" + change);
    }
    private static double calculateTotalCost(double[] prices) {
        double total = 0;
        for (double price : prices) {
            total += price;
        }
        return total;
    }

    private static double calculateChange(double totalCost, double moneyAmount) {
        return moneyAmount - totalCost;



    }
}
