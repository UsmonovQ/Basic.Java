package wedding;
public enum Anniversary {
    PAPER,//1
    COTTON,//2
    LEATHER,//3
    FRUIT_OR_FLOWER,//4
    WOOD,//5
    SUGAR,//6
    COPPER,//7
    BRONZE_OR_POTTERY,//8
    WILLOW,//9
    TIN,//10
    STEEL,//11
    FINE_LINEN,//12
    LACE,//13
    IVORY,//14
    CRYSTAL//15
}


