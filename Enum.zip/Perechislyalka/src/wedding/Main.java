package wedding;

import wedding.Anniversary;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("How many years have you been married ? ");
        int age = sc.nextInt();
        Anniversary choice = switch (age) {
            case 0 -> wedding.Anniversary.PAPER;
            case 1 -> wedding.Anniversary.COTTON;
            case 2 -> wedding.Anniversary.LEATHER;
            case 3 -> wedding.Anniversary.FRUIT_OR_FLOWER;
            case 4 -> wedding.Anniversary.WOOD;
            case 5 -> wedding.Anniversary.SUGAR;
            case 6 -> wedding.Anniversary.COPPER;
            case 7 -> wedding.Anniversary.BRONZE_OR_POTTERY;
            case 8 -> wedding.Anniversary.WILLOW;
            case 9 -> wedding.Anniversary.TIN;
            case 10 -> wedding.Anniversary.STEEL;
            case 11 -> wedding.Anniversary.FINE_LINEN;
            case 12 -> wedding.Anniversary.LACE;
            case 13 -> wedding.Anniversary.IVORY;
            case 14 -> wedding.Anniversary.CRYSTAL;
            default -> throw new IllegalStateException("Select from 1 to 15 yers " + age);
        };
        System.out.println("Your next anniversary will be-" +choice);
    }
}