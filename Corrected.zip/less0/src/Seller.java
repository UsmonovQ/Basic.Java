import java.util.Scanner;

public class Seller {

    public static void main(String[] args) {
        //2 Пользователь-продавец вводит суммарную стоимость покупок и сумму денег, которую дал покупатель.
        // Выведите сумму сдачи в виде “X рублей и Y копеек”.

        Scanner scr = new Scanner(System.in);
       int totalCost = (int) scr.nextInt();
        System.out.println(" Суммарная стоимость покупок; " + totalCost);
        int amountPaid = (int) scr.nextInt();
        System.out.println("Сумму денег которые дал покупатель; " + amountPaid);
        int change =  (int) amountPaid-totalCost;
        int dollars = (int) change;
       int cents = (int) ((change - dollars)*100);
        System.out.println("Сдача: "+ dollars+" Рублей: "+cents+" Копеек:");

    }

}
