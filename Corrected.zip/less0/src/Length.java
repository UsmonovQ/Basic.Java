public class Length {
    public static void main(String[] args) {
        // 1 Дана длина в метрах.
        // Напишите программу, которая переводит указанное значение в км, мили, футы и аршины.
        // Выведите начальное и конвертированные значения на экран.
        double Meters = 1500.0;
        double Kilometers = Meters / 1000.0;
        double Miles = Meters / 1609.34;
        double INFeet = Meters* 3.28084;
        double InArshins = Meters / 0.7112;

        System.out.println(Meters+ " meters");
        System.out.println(Kilometers + " km");
        System.out.println(Miles + " mile");
        System.out.println(INFeet + " feet");
        System.out.println(InArshins + " arshin");


    }
}