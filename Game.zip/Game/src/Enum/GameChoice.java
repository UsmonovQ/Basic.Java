package Enum;

public enum GameChoice {
    STONE,PEPPER,SCISSORS
}
