import Enum.GameChoice;
import java.util.Random;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        //Напишите консольную игру «Камень, ножницы, бумага».
        // Пользователь вводит свой выбор (в виде строки или числа).
        // Программа случайным образом делает свой выбор и выводит на экран.
        // Далее программа показывает, кто победитель – пользователь или программа.
        Scanner sc = new Scanner(System.in);
        System.out.println("Pleas enter SCISSORS (0), PAPPER (1), or STONE (2) ");
        int playerMove = Integer.parseInt(sc.nextLine());
        var player = switch (playerMove) {
            case 0 -> GameChoice.SCISSORS;
            case 1 -> GameChoice.PEPPER;
            case 2 -> GameChoice.STONE;
            default -> throw new IllegalStateException("You entered the number incorrectly " + playerMove);
        };
        System.out.println("PLAYER-" + player);
        Random rnd = new Random();
        int compMove = rnd.nextInt(3);
        GameChoice comp = switch (compMove) {
            case 0 -> GameChoice.SCISSORS;
            case 1 -> GameChoice.PEPPER;
            default -> GameChoice.STONE;
        };
        System.out.println("COMPUTER- " + comp);

        if (playerMove == compMove) {
            System.out.println("DRAW");
        }
        if (player == GameChoice.STONE && comp == GameChoice.SCISSORS ||
                player == GameChoice.PEPPER && comp == GameChoice.STONE ||
                player == GameChoice.SCISSORS && comp == GameChoice.PEPPER) {
            System.out.println("PLAYER WIN'S");
        } else {
            System.out.println("COMP WIN'S");
        }
    }
}