import java.time.DayOfWeek;
import java.util.Scanner;

public class Num3 {
    public static void main(String[] args) {
        //Задание 3
        //Используйте foreach.
        //Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль.
        //Программа должна вывести все дни недели, кроме данного.
        Scanner sc = new Scanner(System.in);
        System.out.println("Введите имя текущего дня: ");
        String today = sc.nextLine().toUpperCase();
        System.out.println("Дни недели, кроме " + today + " ");
        for (DayOfWeek day : DayOfWeek.values()) {
            if (day != DayOfWeek.valueOf(today)) {
                System.out.print(day + " ");
            }
        }
    }
}