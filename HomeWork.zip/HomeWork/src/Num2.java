import java.util.Scanner;

public class Num2 {
    public static void main(String[] args) {
        //Задание 2
        //Используйте for для вычисления суммы.
        //Используйте do-while для организации повторения программы.


        //Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем.
        //Программу повторять, пока пользователь не введёт «quit».

        Scanner scr = new Scanner(System.in);
        String user;
        do {
            System.out.println("Ведите начало диапазона (целое число)");
            int num1 = scr.nextInt();
            System.out.println("Ведите конец диапазона (целое число)");
            int num2 = scr.nextInt();
            int summ = 0;
            for (int i = num1; i < num2; i++) {
                if (i % 2 != 0) {
                    summ += i;
                }
            }
            System.out.println("Сумма Нечетных чисел; " + num1 + "-" + num2 + "=" + summ);
            System.out.println("Для завершение программы введите 'quit: ");
            user = scr.nextLine();
        } while (!user.equalsIgnoreCase("quit"));
        System.out.println("Программа завершена: ");
    }
}


