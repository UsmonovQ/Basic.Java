import java.util.Scanner;

public class Num2 {
    public static void main(String[] args) {
        //№3 Напишите программу, которая получает от пользователя два целых числа и затем вычисляет сумму (сложение),
        // разницу (вычитание), произведение (умножение) и
        // частное (деление) введённых чисел. Результат вычисления выведите в консоль.

        Scanner scanner = new Scanner(System.in);
        int num1 = scanner.nextInt();
        int num2 = scanner.nextInt();
        System.out.println("Сложение-" + (num1 + num2));
        System.out.println("Вычитание-" + (num1 - num2));
        System.out.println("Умножение-" + (num1 * num2));
        System.out.println("Деление-" + (num1 / num2));


    }
}