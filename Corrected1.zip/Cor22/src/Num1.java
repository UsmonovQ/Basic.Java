
import java.util.Scanner;

public class Num1 {
    public static void main(String[] args) {
        //№2
        //Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес.
        // Когда все данные введены, программа должна выдать сообщение:
        // «Уважаемый, [Имя]! В свои [Возраст] лет ыВ для нас дороги, как [Вес] килограмм золота.».
        // В сообщении [Имя], [Возраст] и [Вес] должны принять введённые значения.
        Scanner scanner = new Scanner(System.in);

        System.out.println(" What`s your name? ");
        String name = scanner.next();
        System.out.println("How old are You? ");
        int age = scanner.nextInt();
        System.out.println("How much do you weigh?");
        int weight = scanner.nextInt();
        System.out.println("Уважаемый," + name + "!"+" В свои " +age + " лет Bы для нас дороги, "+" Как "+ weight + " килограмм золота.");

    }
}
