import java.util.Scanner;

public class NUM2 {
    public static void main(String[] args) {
        // Необходимо написать программу, которая проверяет пользователя на знание таблицы умножения.
        // Программа генерирует два целых однозначных числа. Программа задаёт вопрос: результат умножения первого числа на второе?
        // Пользователь должен ввести ответ и увидеть на экране правильно он ответил или нет.
        // Если пользователь ответил неправильно, то программа должна показать правильный ответ.

        Scanner scr = new Scanner(System.in);
        System.out.println("Какой будет результат умножения 10 на 20 ?");
        int Num1 = scr.nextInt();
        if (Num1 == 200) {
            System.out.println("Perfect");
        }
        if (Num1 != 200) {
            System.out.println("The correct answer is 200!!!");
        }

    }
}
