import java.util.AbstractList;
import java.util.Scanner;

public class NUM1 {
    public static void main(String[] args) {
        // Создать программу, выводящую на экран ближайшее к 10 из двух чисел, записанных в переменные m и n.
        //Числа могут быть, как целочисленные, так и дробные.Например :ввод : m=7, n=11 вывод: Число 11 ближе к 10.
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите первое число(m):");
        double m = scr.nextDouble();
        System.out.println("Введите второе число число(n):");
        double n = scr.nextDouble();
        double target = 10;
        double ToM = Math.abs(m - target);
        double ToN = Math.abs(n - target);
        String result = (ToM < ToN) ? (" Число " + m + " ближе к " + target) :
                " Число " + n + " ближе к " + target;
        System.out.println(result);
    }
}