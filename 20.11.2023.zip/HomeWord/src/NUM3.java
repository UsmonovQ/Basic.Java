import javax.swing.*;
import java.util.Scanner;

public class NUM3 {
    public static void main(String[] args) {
        //№3 Элвис Пресли жил с 1935 по 1977 год. Используя тернарные операторы, напишите программу, в которой пользователь вводит год.
        // Если указанный год меньше 1935, то вывести «Элвис ещё не родился».
        // Если указанный пользователем год с 1935 по 1977 включительно, то вывести «Элвис жив!».
        // Если введённый пользователем год больше 1977, то вывести «Элвис навсегда в наших сердцах!»
        System.out.println("V kakom godu rodilsya Elvis");
        Scanner scr = new Scanner(System.in);
        int age = scr.nextInt();
        String status = (age < 1935) ? "«Элвис ещё не родился»." : (age >= 1935 && age <= 1977) ? " «Элвис жив!»" :"«Элвис навсегда в наших сердцах!»";
//String status = count <= 0 ? "бездетная" : (count > 2 ? "многодетная" : " обычная");
        System.out.println(status);


    }
}