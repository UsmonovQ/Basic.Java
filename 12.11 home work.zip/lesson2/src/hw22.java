public class hw22 {
    public static void main(String[] args) {
        char myChar = "G";
        int number = 89;
        byte myByte = 4;
        short myShort = 56;
        float myFloat = 4.7333436f;
        double myDouble = 4.355453532;
        long myLong = 12121;
        System.out.println(myChar);
        System.out.println(number);
        System.out.println(myByte);
        System.out.println(myShort);
        System.out.println(myFloat);
        System.out.println(myDouble);
        System.out.println(myLong);


        //Не знаю почему но я не cмог вывести на консоль:
        //char myChar = 89;


    }
}
