public class hw23 {
    public static void main(String[] args) {
        int number = 345;
        int digit1 = number / 100;
        int digit2 = (number / 10) % 10;
        int digit3 = number % 10;
        System.out.println(digit1);
        System.out.println(digit2);
        System.out.println(digit3);

        int number1 = 987;
        int digit4 = number1 / 100;
        int digit5 = (number1 / 10) % 10;
        int digit6 = number1 % 10;
        System.out.println(digit4);
        System.out.println(digit5);
        System.out.println(digit6);

    }
}
